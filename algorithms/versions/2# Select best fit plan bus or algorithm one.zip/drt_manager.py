import traci
import drt_manager_lib as lib
import drt_manager_listener as listener

def run():
    bus_stops = lib.get_bus_stops("as_stops.add.xml")
    traci.start([
        "sumo-gui", 
        "-c", "sumo.sumocfg", 
        "--device.taxi.dispatch-algorithm", "traci",
        "--delay","1000"
    ])
    
    active_reservations = set()
    bus_manifests = {}

    # NEW: Initialize the queue list
    queue_list = []
    user_to_res_map = {}
    res_to_user_map = {}

    cleaner_listener = listener.ManifestCleanerListener(bus_manifests,user_to_res_map,res_to_user_map)
    traci.addStepListener(cleaner_listener)
    
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        buses = [v for v in traci.vehicle.getIDList() if traci.vehicle.getTypeID(v) == "arts"]
        
        # 1. INITIAL ASSIGNMENT (Status 1)
        # reservations_0 = traci.person.getTaxiReservations(0) 
        # new_reservations = traci.person.getTaxiReservations(1) 
        # retrieved_reservations = traci.person.getTaxiReservations(2)
        waiting_reservations = traci.person.getTaxiReservations(3)
        # assigned_reservations = traci.person.getTaxiReservations(4)
        # reservations_8 = traci.person.getTaxiReservations(8)


        # # --- PRINT PASSENGERS INSIDE EACH BUS EVERY SECOND ---
        # print(f"--- CURRENT BUS STATUS : {traci.simulation.getTime()} ---")
        # for bus in buses: 
        #     # Get the number of people physically riding
            # riding_count = traci.vehicle.getPersonNumber(bus)
            
        #     # Get their actual IDs if you want to see exactly WHO is inside
            # riding_ids = traci.vehicle.getPersonIDList(bus) 
            
            # ---> THE FIX: Sync Python's memory with SUMO's reality <---
            # current_plan = bus_manifests.get(bus, [])
            
            # if current_plan:
                # Running the list through your optimizer instantly deletes 
                # anyone who was picked up or dropped off since the last second!
                # current_plan = lib.optimize_route_sequence(bus, current_plan, 0.2)
                # bus_manifests[bus] = current_plan # Save the cleaned list
            
            # print(f"Bus: {bus} | Riding Count: riding_count | Passengers: riding_ids | Plan: {current_plan}")
        # # # -----------------------------------------------------

        # # ---> THE ULTRA-FAST CLEANER <---
        # # Fetch all active reservations exactly once per second
        # all_active_reservations = traci.person.getTaxiReservations(12)
        # active_res_ids = {res.id for res in all_active_reservations}

        # for bus in buses:
            # current_plan = bus_manifests.get(bus, [])
            
        #     if current_plan:
        #         # Instantly keep only the IDs that are still actively in the simulation.
        #         # If they were dropped off, they disappear from active_res_ids, and are cleanly deleted here!
        #         cleaned_plan = [res_id for res_id in current_plan if res_id in active_res_ids]
                
        #         bus_manifests[bus] = cleaned_plan 
            # print(f"bus_manifests[{bus}] {current_plan}")
        # # -----------------------------------------------------
        

        # print('----------------------------')
        # print(f"Time: {traci.simulation.getTime()}")        
        # print(f"New passengers (1): {[res.persons[0] for res in new_reservations]}")
        # print(f"Waiting passengers (2): {[res.persons[0] for res in retrieved_reservations]}")
        # print(f"New + Waiting passengers (1 + 2): {[res.persons[0] for res in waiting_reservations]}")
        # print(f"Assigned Passengers  (4): {[res.persons[0] for res in assigned_reservations]}")
        # print(f"Picked Up passengers  (8): {[res.persons[0] for res in reservations_8]}") 
        # print('----------------------------')

        for res in waiting_reservations[:2]:
            
            if res.id in active_reservations:
                continue
                     

            # user_edge = res.fromEdge
            
            user_id = res.persons[0]
            sorted_buses = lib.get_marginal_cost_sorted_buses(res, buses, bus_manifests)
            assigned_successfully = False


            for bus in sorted_buses:


                # riding_count = traci.vehicle.getPersonNumber(closest_bus)
                # capacity = traci.vehicle.getPersonCapacity(closest_bus) 
                
                # # 3. Check if it is full (riding_count is greater than or equal to capacity)
                # if riding_count >= capacity:
                #     print(f"closest_bus {closest_bus} is full! (Riding: {riding_count}/{capacity}) user_id: {user_id}")
                #     continue
                current_manifest = bus_manifests.get(bus, [])
                total_assigned_people = len(set(current_manifest)) # Count unique IDs
                try:
                    capacity = traci.vehicle.getPersonCapacity(bus) 
                except:
                    capacity = 12


                # If this bus is hoarding, skip it and check the NEXT closest bus!
                if total_assigned_people >= (capacity):
                    continue
                

                try:
                    # 1. Get the current planned route for this bus (or an empty list)
                    manifest = bus_manifests.get(bus, [])
                    
                    # active_passengers = traci.vehicle.getPersonNumber(closest_bus) #//
                    # print(f"active_passengers {active_passengers}")

                    # 2. Add the new person to the bus's plan.
                    # We append the ID TWICE. The 1st time means "Pickup", the 2nd means "Drop-off".
                    # if traci.simulation.getTime()>1:
                    #     continue

                    manifest.append(res.id) # Pickup
                    manifest.append(res.id) # Drop-off
                    
                    # (Later, you can write logic here to sort this list to minimize distance!)
                    manifest = lib.optimize_route_sequence(bus, manifest,res, 1.0)
            

                    # 3. Send the entire grouped list to the bus
                    traci.vehicle.dispatchTaxi(bus, manifest)
                    
                    # 4. Save the updated list back to your trackers
                    bus_manifests[bus] = manifest
                    active_reservations.add(res.id)
                    user_to_res_map[user_id] = res.id   
                    res_to_user_map[res.id] = user_id
                    
                    # print(manifest)                  
                    print(f"Assigned {user_id} (Res: {res.id}) to {bus}. Current plan: {manifest}")

                    assigned_successfully = True
                    break
                    
                except traci.exceptions.TraCIException as e:
                    print(f"Failed to assign {user_id} to {bus}: {e}")

            # 3. If we checked ALL 6 buses and none of them worked...
            if not assigned_successfully:
                if user_id not in queue_list:
                    queue_list.append(user_id)
                    print(f"All 6 buses are full! User {user_id} added to queue.")

    traci.close()
if __name__ == "__main__":
    run()