import traci
import math
import xml.etree.ElementTree as ET

ROUTE_CACHE = {}

def get_sorted_buses(user_id, buses):
    """
    Calculates the distance to every bus and returns a list of all buses,
    sorted from absolute closest to furthest.
    """
    if not buses:
        return []
        
    user_pos = traci.person.getPosition(user_id)
    bus_distances = []
    
    for bus in buses:
        bus_pos = traci.vehicle.getPosition(bus)
        distance = math.dist(user_pos, bus_pos) 
        bus_distances.append((distance, bus))
        
    # Sort the list by distance (shortest to longest)
    bus_distances.sort()
    
    # Return just the bus IDs in order
    return [bus for dist, bus in bus_distances]


def get_travel_time(start_edge, end_edge):
    # If they are on the same street, the distance is 0!
    if start_edge == end_edge:
        return 0
        
    pair = (start_edge, end_edge)
    
    # If we have NEVER calculated this route before, ask SUMO
    if pair not in ROUTE_CACHE:
        try:
            route = traci.simulation.findRoute(start_edge, end_edge)
            ROUTE_CACHE[pair] = route.travelTime if len(route.edges) > 0 else float('inf')
        except traci.exceptions.TraCIException:
            ROUTE_CACHE[pair] = float('inf')
            
    # Return the saved answer instantly
    return ROUTE_CACHE[pair]


def get_bus_stops(stop_xml_file):
    """Reads the XML and creates a simple dictionary mapping {Edge: BusStop_ID}"""
    tree = ET.parse(stop_xml_file)
    stops = {}
    for stop in tree.getroot().findall('busStop'):
        lane = stop.get('lane')
        if lane:
            edge = lane.rsplit('_', 1)[0]
            stops[edge] = stop.get('id')
    return stops


def optimize_route_sequence(bus_id, manifest, new_res=None, dropoff_weight=1):
    """
    Analyzes a taxi manifest and re-orders it using a Greedy Nearest-Neighbor approach.
    Includes a Virtual Occupancy Tracker to prevent scheduling more pickups 
    than the vehicle's physical capacity allows.
    
    :param bus_id: The ID of the vehicle.
    :param manifest: The list of reservation IDs assigned to the vehicle.
    :param dropoff_weight: Float between 0.0 and 1.0 to artificially reduce drop-off distances.
        -> Range: (0.0 to 1.0]. Default is 0.2.
        -> 0.1 (Heavy Drop-off Priority): The bus will almost always drop people off before 
           picking up new ones. Passengers get home very fast, but the bus drives more miles.
        -> 0.9 (Light Drop-off Priority): The bus behaves almost like standard Nearest-Neighbor. 
           It will gladly detour to pick up nearby people, even if passengers are waiting inside. 
           Highly efficient for the fleet, but passengers may be trapped inside for a long time.
        -> 1.0 (Neutral): Distance is the only factor.
    """
    if not manifest:
        return []

    # 1. Fetch details using safe bitmasks
    handled = traci.person.getTaxiReservations(12) # People on the buses
    waiting = traci.person.getTaxiReservations(3)  # People in the queue
    
    all_res = list(handled) + list(waiting)
    res_map = {r.id: r for r in all_res}
    res_map = {r.id: r for r in all_res}
    
    
    if new_res:
        res_map[new_res.id] = new_res


    needs_pickup = set()
    needs_dropoff = set()
    
    # Get the actual physical capacity of the vehicle from SUMO
    try:
        max_capacity = traci.vehicle.getPersonCapacity(bus_id)
    except traci.exceptions.TraCIException:
        max_capacity = 12 # Fallback just in case
        
    simulated_occupancy = 0
    
    # 2. Check actual SUMO state and count current riders
    unique_ids = set(manifest)
    for rid in unique_ids:
        if rid not in res_map:
            continue # If they are missing, their trip is already completely finished!
            
        state = res_map[rid].state
        
        if state == 8: 
            # State 8 means they are ALREADY RIDING in the bus!
            needs_dropoff.add(rid)
            simulated_occupancy += 1 # Add them to our virtual counter
        else:
            # States 1, 2, or 4 mean they are still waiting on the sidewalk.
            needs_pickup.add(rid)
    
    # 3. Get the bus's exact starting location
    current_edge = traci.vehicle.getRoadID(bus_id)
    if current_edge.startswith(":") or current_edge == "": # Failsafe if the bus is inside an intersection
        try:
            route = traci.vehicle.getRoute(bus_id)
            idx = traci.vehicle.getRouteIndex(bus_id)
            current_edge = route[idx]
        except traci.exceptions.TraCIException:
            pass

    optimized_manifest = []
    
    
    # 4. Greedy Loop: Always choose the closest valid action
    while needs_pickup or needs_dropoff:
        best_action = None
        best_cost = float('inf')
        best_is_pickup = False
        target_edge_for_best = ""
        
        # --- Check all possible PICKUPS ---
        # ONLY check pickups if our simulated future bus has empty seats!
        if simulated_occupancy < max_capacity:
            for res_id in needs_pickup:
                if res_id in res_map:
                    target_edge = res_map[res_id].fromEdge
                    
                    # if current_edge == target_edge:
                    #     cost = 0
                    # else:
                    #     route = traci.simulation.findRoute(current_edge, target_edge)
                    #     cost = route.travelTime if len(route.edges) > 0 else float('inf')
                    cost = get_travel_time(current_edge, target_edge)

                    if cost < best_cost:
                        best_cost = cost
                        best_action = res_id
                        best_is_pickup = True
                        target_edge_for_best = target_edge
                    
        # --- Check all possible DROP-OFFS ---
        # Drop-offs are ALWAYS allowed because they free up space.
        for res_id in needs_dropoff:
            if res_id in res_map:
                target_edge = res_map[res_id].toEdge
                
                # if current_edge == target_edge:
                #     cost = 0
                # else:
                #     route = traci.simulation.findRoute(current_edge, target_edge)
                #     cost = route.travelTime if len(route.edges) > 0 else float('inf')

                cost = get_travel_time(current_edge, target_edge)


                # Multiply cost by 0.2 to artificially make drop-offs look closer.
                # This prevents passengers from being trapped in the bus for a long time!
                cost = cost * dropoff_weight

                if cost < best_cost:
                    best_cost = cost
                    best_action = res_id
                    best_is_pickup = False
                    target_edge_for_best = target_edge
                    
        # 5. Apply the best action found to the new list
        if best_action is not None:
            optimized_manifest.append(best_action)
            current_edge = target_edge_for_best # Move our virtual location to this stop
            
            if best_is_pickup:
                needs_pickup.remove(best_action)
                needs_dropoff.add(best_action) # Now they need a drop-off
                simulated_occupancy += 1       # A passenger got on, take up a seat!
            else:
                needs_dropoff.remove(best_action)
                simulated_occupancy -= 1       # A passenger got off, free up a seat!
        else:
            # Failsafe: if routing completely fails, append whatever is left
            for p in needs_pickup:
                optimized_manifest.extend([p, p])
            for d in needs_dropoff:
                optimized_manifest.append(d)
            break
            
    return optimized_manifest

def get_manifest_cost(bus_id, manifest, res_map):
    """
    A lightweight simulator that calculates the exact total driving time 
    of a sequence of stops.
    """
    if not manifest:
        return 0
        
    current_edge = traci.vehicle.getRoadID(bus_id)
    if current_edge.startswith(":") or current_edge == "":
        try:
            route = traci.vehicle.getRoute(bus_id)
            idx = traci.vehicle.getRouteIndex(bus_id)
            current_edge = route[idx]
        except traci.exceptions.TraCIException:
            pass

    total_time = 0
    seen_counts = {}
    
    for res_id in manifest:
        if res_id not in res_map:
            continue
            
        seen_counts[res_id] = seen_counts.get(res_id, 0) + 1
        res = res_map[res_id]
        
        # Determine if this step is a pickup or drop-off
        is_pickup = False
        if res.state == 8:
            # If they are already riding, their only stop left is a drop-off
            is_pickup = False
        else:
            # If they are waiting, the 1st appearance is pickup, 2nd is drop-off
            if seen_counts[res_id] == 1:
                is_pickup = True
            else:
                is_pickup = False
                
        target_edge = res.fromEdge if is_pickup else res.toEdge
        
        # Add the driving time to the total cost
        leg_time = get_travel_time(current_edge, target_edge)
        total_time += leg_time
        
        # Move our virtual bus to this stop for the next loop
        current_edge = target_edge
        
    return total_time

def get_marginal_cost_sorted_buses(new_res, buses, bus_manifests):
    """
    The Marginal Cost Sorter! 
    Calculates exactly how much extra driving time is added to a bus's shift 
    if we assign them this specific passenger.
    """
    if not buses:
        return []
        
    # Fetch all active reservations once for cost evaluation
    try:
        handled_res = traci.person.getTaxiReservations(12) 
        res_map = {r.id: r for r in handled_res}
    except traci.exceptions.TraCIException:
        res_map = {}
        
    res_map[new_res.id] = new_res # Add the new passenger to our map
    
    bus_margins = []
    
    for bus in buses:
        current_manifest = bus_manifests.get(bus, [])
        
        # 1. Calculate Base Cost (How long is the route right now?)
        base_cost = get_manifest_cost(bus, current_manifest, res_map)
        
        # 2. Simulate inserting the new passenger
        test_manifest = current_manifest.copy()
        test_manifest.extend([new_res.id, new_res.id])
        
        # We run it through your optimizer to find the best possible sequence
        optimized_test = optimize_route_sequence(bus, test_manifest, new_res=new_res, dropoff_weight=1.0)
        
        # 3. Calculate New Cost (How long is the route WITH the new passenger?)
        new_cost = get_manifest_cost(bus, optimized_test, res_map)
        
        # ---> 4. THE MARGIN! <---
        margin = new_cost - base_cost
        
        bus_margins.append((margin, bus))
        
    # Sort by the lowest margin (least added delay to the system)
    bus_margins.sort()
    
    # Return just the bus IDs in order of best to worst
    return [bus for margin, bus in bus_margins]