import traci
import math
import xml.etree.ElementTree as ET

ROUTE_CACHE = {}

def get_sorted_buses(user_id, buses):
    """
    Calculates the distance to every bus and returns a list of all buses,
    sorted from absolute closest to furthest.
    """
    if not buses:
        return []
        
    user_pos = traci.person.getPosition(user_id)
    bus_distances = []
    
    for bus in buses:
        bus_pos = traci.vehicle.getPosition(bus)
        distance = math.dist(user_pos, bus_pos) 
        bus_distances.append((distance, bus))
        
    # Sort the list by distance (shortest to longest)
    bus_distances.sort()
    
    # Return just the bus IDs in order
    return [bus for dist, bus in bus_distances]

def get_bus_stops(stop_xml_file):
    """Reads the XML and creates a simple dictionary mapping {Edge: BusStop_ID}"""
    tree = ET.parse(stop_xml_file)
    stops = {}
    for stop in tree.getroot().findall('busStop'):
        lane = stop.get('lane')
        if lane:
            edge = lane.rsplit('_', 1)[0]
            stops[edge] = stop.get('id')
    return stops


def optimize_route_sequence(bus_id, manifest, dropoff_weight=1):
    """
    Analyzes a taxi manifest and re-orders it using a Greedy Nearest-Neighbor approach.
    Includes a Virtual Occupancy Tracker to prevent scheduling more pickups 
    than the vehicle's physical capacity allows.
    
    :param bus_id: The ID of the vehicle.
    :param manifest: The list of reservation IDs assigned to the vehicle.
    :param dropoff_weight: Float between 0.0 and 1.0 to artificially reduce drop-off distances.
        -> Range: (0.0 to 1.0]. Default is 0.2.
        -> 0.1 (Heavy Drop-off Priority): The bus will almost always drop people off before 
           picking up new ones. Passengers get home very fast, but the bus drives more miles.
        -> 0.9 (Light Drop-off Priority): The bus behaves almost like standard Nearest-Neighbor. 
           It will gladly detour to pick up nearby people, even if passengers are waiting inside. 
           Highly efficient for the fleet, but passengers may be trapped inside for a long time.
        -> 1.0 (Neutral): Distance is the only factor.
    """
    if not manifest:
        return []

    # 1. Fetch details using safe bitmasks
    handled = traci.person.getTaxiReservations(12) # People on the buses
    waiting = traci.person.getTaxiReservations(3)  # People in the queue
    
    all_res = list(handled) + list(waiting)
    res_map = {r.id: r for r in all_res}
    res_map = {r.id: r for r in all_res}
    
    needs_pickup = set()
    needs_dropoff = set()
    
    # Get the actual physical capacity of the vehicle from SUMO
    try:
        max_capacity = traci.vehicle.getPersonCapacity(bus_id)
    except traci.exceptions.TraCIException:
        max_capacity = 12 # Fallback just in case
        
    simulated_occupancy = 0
    
    # 2. Check actual SUMO state and count current riders
    unique_ids = set(manifest)
    for rid in unique_ids:
        if rid not in res_map:
            continue # If they are missing, their trip is already completely finished!
            
        state = res_map[rid].state
        
        if state == 8: 
            # State 8 means they are ALREADY RIDING in the bus!
            needs_dropoff.add(rid)
            simulated_occupancy += 1 # Add them to our virtual counter
        else:
            # States 1, 2, or 4 mean they are still waiting on the sidewalk.
            needs_pickup.add(rid)
    
    # 3. Get the bus's exact starting location
    current_edge = traci.vehicle.getRoadID(bus_id)
    if current_edge.startswith(":") or current_edge == "": # Failsafe if the bus is inside an intersection
        try:
            route = traci.vehicle.getRoute(bus_id)
            idx = traci.vehicle.getRouteIndex(bus_id)
            current_edge = route[idx]
        except traci.exceptions.TraCIException:
            pass

    optimized_manifest = []

    # ---> THE CACHE HELPER <---
    def get_travel_time(start_edge, end_edge):
        # If they are on the same street, the distance is 0!
        if start_edge == end_edge:
            return 0
            
        pair = (start_edge, end_edge)
        
        # If we have NEVER calculated this route before, ask SUMO
        if pair not in ROUTE_CACHE:
            route = traci.simulation.findRoute(start_edge, end_edge)
            ROUTE_CACHE[pair] = route.travelTime if len(route.edges) > 0 else float('inf')
            
        # Return the saved answer instantly
        return ROUTE_CACHE[pair]
    
    
    # 4. Greedy Loop: Always choose the closest valid action
    while needs_pickup or needs_dropoff:
        best_action = None
        best_cost = float('inf')
        best_is_pickup = False
        target_edge_for_best = ""
        
        # --- Check all possible PICKUPS ---
        # ONLY check pickups if our simulated future bus has empty seats!
        if simulated_occupancy < max_capacity:
            for res_id in needs_pickup:
                if res_id in res_map:
                    target_edge = res_map[res_id].fromEdge
                    
                    # if current_edge == target_edge:
                    #     cost = 0
                    # else:
                    #     route = traci.simulation.findRoute(current_edge, target_edge)
                    #     cost = route.travelTime if len(route.edges) > 0 else float('inf')
                    cost = get_travel_time(current_edge, target_edge)

                    if cost < best_cost:
                        best_cost = cost
                        best_action = res_id
                        best_is_pickup = True
                        target_edge_for_best = target_edge
                    
        # --- Check all possible DROP-OFFS ---
        # Drop-offs are ALWAYS allowed because they free up space.
        for res_id in needs_dropoff:
            if res_id in res_map:
                target_edge = res_map[res_id].toEdge
                
                # if current_edge == target_edge:
                #     cost = 0
                # else:
                #     route = traci.simulation.findRoute(current_edge, target_edge)
                #     cost = route.travelTime if len(route.edges) > 0 else float('inf')

                cost = get_travel_time(current_edge, target_edge)


                # Multiply cost by 0.2 to artificially make drop-offs look closer.
                # This prevents passengers from being trapped in the bus for a long time!
                cost = cost * dropoff_weight

                if cost < best_cost:
                    best_cost = cost
                    best_action = res_id
                    best_is_pickup = False
                    target_edge_for_best = target_edge
                    
        # 5. Apply the best action found to the new list
        if best_action is not None:
            optimized_manifest.append(best_action)
            current_edge = target_edge_for_best # Move our virtual location to this stop
            
            if best_is_pickup:
                needs_pickup.remove(best_action)
                needs_dropoff.add(best_action) # Now they need a drop-off
                simulated_occupancy += 1       # A passenger got on, take up a seat!
            else:
                needs_dropoff.remove(best_action)
                simulated_occupancy -= 1       # A passenger got off, free up a seat!
        else:
            # Failsafe: if routing completely fails, append whatever is left
            for p in needs_pickup:
                optimized_manifest.extend([p, p])
            for d in needs_dropoff:
                optimized_manifest.append(d)
            break
            
    return optimized_manifest


    # Track lanes instead of edges to print exactly when entering a new lane
    # bus_previous_lanes = {} 
 # 2. OPPORTUNISTIC PICKUP & LANE PRINTING
        # for bus in buses:
        #     curr_lane = traci.vehicle.getLaneID(bus)
            
        #     # If the bus just entered a new real lane (ignore intersections starting with ":")
        #     if curr_lane != bus_previous_lanes.get(bus, "") and not curr_lane.startswith(":"):
        #         bus_previous_lanes[bus] = curr_lane
                
        #         # Get the edge from the lane to check for stops and passengers
        #         curr_edge = curr_lane.rsplit('_', 1)[0]
        #         stop_id = bus_stops.get(curr_edge, "None")
                
        #         # Find all people waiting at this edge and their status
        #         waiting_passengers = []
        #         for res in new_reservations:
        #             if res.fromEdge == curr_edge:
        #                 waiting_passengers.append(f"{res.persons[0]} (Status 1)")
        #         for res in retrieved_reservations:
        #             if res.fromEdge == curr_edge:
        #                 waiting_passengers.append(f"{res.persons[0]} (Status 2)")
        #         for res in waiting_reservations:
        #             if res.fromEdge == curr_edge:
        #                 waiting_passengers.append(f"{res.persons[0]} (Status 3)")
        #         for res in assigned_reservations:
        #             if res.fromEdge == curr_edge:
        #                 waiting_passengers.append(f"{res.persons[0]} (Status 4)")

        #         people_str = ", ".join(waiting_passengers) if waiting_passengers else "None"
                
        #         # ---> THE REQUESTED PRINT STATEMENT <---
        #         print(f"Bus: {bus} | Lane: {curr_lane} | Stop: {stop_id} | Persons: {people_str}")
                
        #         # Opportunistic stealing logic for Status 4 (Assigned) passengers
        #         if stop_id != "None":
        #             for res in assigned_reservations:
        #                 if res.fromEdge == curr_edge:
        #                     user_id = res.persons[0]
        #                     old_bus = user_assignments.get(user_id, "Unknown")
                            
        #                     # SAFETY CHECK: Determine if it's safe to steal
        #                     # We cannot wipe the old bus if it already has passengers physically riding inside it
        #                     is_safe_to_steal = True
        #                     if old_bus != "Unknown" and old_bus in bus_manifests:
        #                         all_res_check = traci.person.getTaxiReservations(0)
        #                         res_map_check = {r.id: r for r in all_res_check}
        #                         for r_id in bus_manifests[old_bus]:
        #                             if r_id in res_map_check and res_map_check[r_id].state == 8:
        #                                 # Someone is riding! We must abort the steal.
        #                                 is_safe_to_steal = False
        #                                 break
                            
        #                     # Steal them ONLY if they belong to another bus AND it is safe
        #                     if old_bus != bus and is_safe_to_steal:
        #                         try:
        #                             # --- 1. UPDATE THE OLD BUS (The Radio Communication Trick) ---
        #                             if old_bus != "Unknown" and old_bus in bus_manifests:
        #                                 # First, send an empty list to completely wipe the old bus's memory
        #                                 # This bypasses the SUMO "failed to mention" 0xc4 error!
        #                                 traci.vehicle.dispatchTaxi(old_bus, [])
                                        
        #                                 # Now build its new plan WITHOUT the stolen passenger
        #                                 old_manifest = [r for r in bus_manifests[old_bus] if r != res.id]
        #                                 optimized_old = lib.optimize_route_sequence(old_bus, old_manifest)
                                        
        #                                 # Send the remaining optimized route back to the old bus
        #                                 if optimized_old:
        #                                     traci.vehicle.dispatchTaxi(old_bus, optimized_old)
                                            
        #                                 bus_manifests[old_bus] = optimized_old

        #                             # --- 2. UPDATE THE NEW (STEALING) BUS ---
        #                             manifest = bus_manifests.get(bus, [])
        #                             manifest.append(res.id)
        #                             manifest.append(res.id)
                                    
        #                             # Optimize the new bus's route with the new passenger
        #                             optimized_new = lib.optimize_route_sequence(bus, manifest)
        #                             traci.vehicle.dispatchTaxi(bus, optimized_new)
                                    
        #                             # Save trackers
        #                             bus_manifests[bus] = optimized_new
        #                             user_assignments[user_id] = bus 
                                    
        #                             print(f"  *** STOLEN: Bus {bus} took {user_id} from {old_bus}! ***")
        #                             print(f"  *** Bus {bus} New Plan: {optimized_new} ***")
        #                             if old_bus != "Unknown":
        #                                 print(f"  *** Bus {old_bus} Remaining Plan: {bus_manifests[old_bus]} ***")
                                    
        #                         except traci.exceptions.TraCIException as e:
        #                             print(f"  *** FAILED to steal {user_id} for Bus {bus}: {e} ***")
