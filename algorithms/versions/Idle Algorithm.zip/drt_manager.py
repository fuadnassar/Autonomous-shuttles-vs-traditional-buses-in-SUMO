import traci
import drt_manager_lib as lib
import drt_manager_listener as listener

def run():
    bus_stops = lib.get_bus_stops("as_stops.add.xml")
    traci.start([
        "sumo-gui", 
        "-c", "sumo.sumocfg", 
        "--device.taxi.dispatch-algorithm", "traci"
        ,"--delay","1000"
    ])
    
    max_dropoff_delay=60
    max_pickup_delay=120

    active_reservations = set()
    bus_manifests = {}
    queue_list = []
    user_to_res_map = {}
    res_to_user_map = {}

    promised_pickup_times = {}
    waiting_for_pickup = set()
    all_eta_delays = []  
    
    cleaner_listener = listener.drt_manager_Listener(bus_manifests,user_to_res_map,res_to_user_map)
    traci.addStepListener(cleaner_listener)
    
    # ---> NEW: Ensure data is cached only once <---
    data_initialized = False
    
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        buses = [v for v in traci.vehicle.getIDList() if traci.vehicle.getTypeID(v) == "arts"]
        
        # ---> NEW: Fire the lib setup immediately when buses appear <---
        if not data_initialized and len(buses) > 0:
            lib.init_simulation_data(buses)
            data_initialized = True
            
        current_time = traci.simulation.getTime()
        
        # ---> NEW: Fire the lib setup immediately when buses appear <---
        if not data_initialized and len(buses) > 0:
            lib.init_simulation_data(buses)
            data_initialized = True
            
        current_time = traci.simulation.getTime()
        
        # ==========================================================
        # ---> NEW: HARDCODED TIMED TEST AT SECOND 375 <---
        # ==========================================================
        if current_time == 290.0:
            print("\n" + "="*50)
            print("🕒 TIME 375: INITIATING EMPTY RELOCATION TEST")
            
            target_stop = "bs_68"
            
            try:
                # 1. Find the edge for bs_10 so we can route the bus
                lane_id = traci.busstop.getLaneID(target_stop)
                target_edge = lane_id.split('_')[0]
                
                # 2. Find which bus is currently parked at bs_73
                test_bus = None
                for b_id, parked_stop in cleaner_listener.idle_parked_buses.items():
                    if parked_stop == "bs_73":
                        test_bus = b_id
                        break
                        
                if test_bus:
                    print(f"🚌 Found {test_bus} at bs_73. Relocating to {target_stop}...")
                    
                    # 3. Release the space at bs_73 right now
                    lib.release_idle_parking(test_bus, "bs_73")
                    
                    # 4. Tell the listener this bus is now on the road
                    cleaner_listener.idle_parked_buses[test_bus] = "ROAD_PARKING"
                    
                    # 5. Command SUMO to physically drive the bus there
                    traci.vehicle.resume(test_bus) # Wake it up from bs_73
                    traci.vehicle.changeTarget(test_bus, target_edge) # Draw route
                    traci.vehicle.setBusStop(test_bus, target_stop, duration=3600, flags=1) # Park it
                else:
                    print("⚠️ Test failed: No bus was found parked at bs_73 at time 375.")
                    
            except traci.exceptions.TraCIException as e:
                print(f"⚠️ TraCI Error during test: {e}")
                
            print("="*50 + "\n")
        # ==========================================================


        for bus in buses:
            try:
                riding_ids = traci.vehicle.getPersonIDList(bus)
                for uid in riding_ids:
                    if uid in waiting_for_pickup:
                        waiting_for_pickup.remove(uid)
                        promised_time = promised_pickup_times[uid]
                        eta_delay = current_time - promised_time
                        all_eta_delays.append(eta_delay)
            except traci.exceptions.TraCIException:
                pass

        waiting_reservations = traci.person.getTaxiReservations(3)

        for res in waiting_reservations[:2]:
            if res.id in active_reservations:
                continue
                    
            user_id = res.persons[0]
            sorted_buses = lib.get_marginal_cost_sorted_buses(
                res, buses, bus_manifests, 
                current_time=current_time, 
                promised_pickup_times=promised_pickup_times,
                res_to_user_map=res_to_user_map,
                max_dropoff_delay=max_dropoff_delay, 
                max_pickup_delay=max_pickup_delay,
            )

            assigned_successfully = False
            for bus in sorted_buses:
                current_manifest = bus_manifests.get(bus, [])
                total_assigned_people = len(set(current_manifest)) 
                
                try:
                    capacity = traci.vehicle.getPersonCapacity(bus) 
                except:
                    capacity = 40
                
                effective_limit = capacity

                if total_assigned_people >= (effective_limit):
                    continue
                
                try:
                    manifest = bus_manifests.get(bus, [])
                    manifest.append(res.id) 
                    manifest.append(res.id) 
                    
                    manifest = lib.optimize_route_sequence(bus, manifest, new_res=res, dropoff_weight=1.0)
            
                    traci.vehicle.dispatchTaxi(bus, manifest)
                    
                    bus_manifests[bus] = manifest
                    active_reservations.add(res.id)
                    user_to_res_map[user_id] = res.id   
                    res_to_user_map[res.id] = user_id
                    
                    eta_seconds = lib.get_pickup_eta(bus, manifest, res)
                    eta_minutes = round(eta_seconds / 60, 1)
                    
                    promised_pickup_times[user_id] = current_time + eta_seconds
                    waiting_for_pickup.add(user_id)
                    
                    print(f"   --> 🗺️{bus} Current Plan: {manifest}")

                    assigned_successfully = True
                    break
                    
                except traci.exceptions.TraCIException as e:
                    print(f"Failed to assign {user_id} to {bus}: {e}")

            if not assigned_successfully:
                if user_id not in queue_list:
                    queue_list.append(user_id)
                    print(f"All buses are full! User {user_id} added to queue.")

    traci.close()
    
    if all_eta_delays:
        avg_drift = sum(all_eta_delays) / len(all_eta_delays)
        print("\n" + "="*45)
        print(f"📉 ALGORITHM ACCURACY: AVG ETA DELAY = {round(avg_drift, 2)} seconds")
        print("="*45 + "\n")

if __name__ == "__main__":
    run()