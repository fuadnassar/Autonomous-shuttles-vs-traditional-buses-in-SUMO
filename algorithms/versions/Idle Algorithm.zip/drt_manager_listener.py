import traci
import drt_manager_lib as lib

class drt_manager_Listener(traci.StepListener):
    def __init__(self, bus_manifests, user_to_res_map, res_to_user_map):
        self.bus_manifests = bus_manifests
        self.user_to_res_map = user_to_res_map
        self.res_to_user_map = res_to_user_map
        # Maps bus_id -> stop_id to remember where they parked and release space later
        self.idle_parked_buses = {}
    
    def step(self, t=0):
        buses = [v for v in traci.vehicle.getIDList() if traci.vehicle.getTypeID(v) == "arts"]
        current_time = traci.simulation.getTime()

        for bus in buses:
            current_plan = self.bus_manifests.get(bus, [])
            
            # ==========================================
            # NEW: IDLE PARKING LOGIC
            # ==========================================
            if not current_plan:
                if bus not in self.idle_parked_buses or self.idle_parked_buses[bus] == "ROAD_PARKING":
                    # Bus just became empty! Find out which stop it is currently at
                    current_stop = None
                    try:
                        all_stops = traci.busstop.getIDList()
                        for s in all_stops:
                            if bus in traci.busstop.getVehicleIDs(s):
                                current_stop = s
                                break
                    except traci.exceptions.TraCIException:
                        pass
                        
                    if current_stop:
                        # Send idle request to our list cache
                        can_park = lib.request_idle_parking(bus, current_stop)
                        
                        if can_park:
                            self.idle_parked_buses[bus] = current_stop
                            
                        else:
                            # ---> NEW: Unpack the tuple (stop, edge) <---
                            next_stop_info = lib.find_and_reserve_next_open_stop(bus)
                            if next_stop_info:
                                next_stop, next_edge = next_stop_info
                                self.idle_parked_buses[bus] = next_stop
                                try:
                                    # ---> NEW: Build a route to the target edge first! <---
                                    traci.vehicle.changeTarget(bus, next_edge)
                                    # Now it is safe to command the stop
                                    traci.vehicle.setBusStop(bus, next_stop, duration=3600, flags=1)
                                except traci.exceptions.TraCIException:
                                    pass
                    else:
                        # The bus is empty but NOT at any bus stop (e.g., spawned at E5).
                        self.idle_parked_buses[bus] = "ROAD_PARKING"

                continue # Skip manifest cleanup since it's empty
            else:
                # If it HAS a plan but was previously parked, release the space!
                if bus in self.idle_parked_buses:
                    parked_location = self.idle_parked_buses[bus]
                    
                    if parked_location != "ROAD_PARKING":
                        lib.release_idle_parking(bus, parked_location)
                        
                    del self.idle_parked_buses[bus]

            # ==========================================
            # MANIFEST CLEANUP LOGIC (Original)
            # ==========================================
            passenger_ids = traci.vehicle.getPersonIDList(bus)
            onboard_res_ids = {self.user_to_res_map.get(uid) for uid in passenger_ids}
            
            cleaned_plan = []
            alive_ids = set()
            dead_ids = set()
            
            total_counts = {r_id: current_plan.count(r_id) for r_id in set(current_plan)}
            seen_counts = {}

            for res_id in current_plan:
                seen_counts[res_id] = seen_counts.get(res_id, 0) + 1
                
                if res_id in onboard_res_ids:
                    if total_counts[res_id] == 2 and seen_counts[res_id] == 1:
                        continue 
                    cleaned_plan.append(res_id)
                    continue
                    
                is_alive = False
                
                if res_id in alive_ids:
                    is_alive = True
                elif res_id in dead_ids:
                    is_alive = False
                else:
                    person_id = self.res_to_user_map.get(res_id)
                    try:
                        stage = traci.person.getStage(person_id)
                        if stage.type == 3: 
                            alive_ids.add(res_id)
                            is_alive = True
                        else:
                            dead_ids.add(res_id) 
                    except traci.exceptions.TraCIException:
                        dead_ids.add(res_id) 
                
                if is_alive:
                    cleaned_plan.append(res_id)
            
            self.bus_manifests[bus] = cleaned_plan

        return True